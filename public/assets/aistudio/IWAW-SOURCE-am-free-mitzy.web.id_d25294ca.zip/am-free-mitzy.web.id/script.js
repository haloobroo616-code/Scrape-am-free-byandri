/* ===== inline script 1/1 (dari index.html) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari robots.txt) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari sitemap.xml) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari width=device-width, initial-scale=1.0) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari Layanan verifikasi akun Alight Motion Premium secara free.) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari style_7.css) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);

/* ===== inline script 1/1 (dari script_8.js) ===== */
const emailInput = document.getElementById("email");
const sendBtn = document.getElementById("sendBtn");
const sendStatus = document.getElementById("sendStatus");
const card2 = document.getElementById("card2");
const card3 = document.getElementById("card3");
const verifyLink = document.getElementById("verifyLink");
const verifyBtn = document.getElementById("verifyBtn");
const verifyStatus = document.getElementById("verifyStatus");
const progress1 = document.getElementById("progress1");
const progress2 = document.getElementById("progress2");
const progress3 = document.getElementById("progress3");
const line1 = document.getElementById("line1");
const line2 = document.getElementById("line2");
const welcomePopup = document.getElementById("welcome-popup");
const noShowCheckbox = document.getElementById("no-show-again");
const hidePopup = localStorage.getItem("mitzy_popup_hidden");
if (hidePopup !== "1") {
  setTimeout(() => {
    welcomePopup.classList.add("show");
  }
  ,
  700);
}
function closeWelcomePopup() {
  welcomePopup.classList.remove("show");
}
function toggleNoShow(el) {
  if (el.checked) {
    localStorage.setItem("mitzy_popup_hidden",
    "1");
  }
  else {
    localStorage.removeItem("mitzy_popup_hidden");
  }
}
welcomePopup.addEventListener("click",
(e) => {
  if (e.target === welcomePopup) closeWelcomePopup();
}
);
document.addEventListener("keydown",
(e) => {
  if (e.key === "Escape" && welcomePopup.classList.contains("show")) {
    closeWelcomePopup();
  }
}
);
function validEmail(value) {
  return /^[
    ^\s@
  ]
  +@[
    ^\s@
  ]
  +\.[
    ^\s@
  ]
  +$/.test(value);
}
function validVerificationLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" &&
    (url.hostname === "alight-creative.firebaseapp.com" ||
    url.hostname === "alightcreative.com");
  }
  catch {
    return false;
  }
}
function setVerifyMessage(icon,
title,
message,
success = false) {
  verifyStatus.querySelector(".status-icon").innerHTML = icon;
  verifyStatus.querySelector("strong").textContent = title;
  verifyStatus.querySelector("span").textContent = message;
  verifyStatus.querySelector(".status-icon").style.background =
  success ? "var(--green)" : "var(--primary)";
}
const COOLDOWN_MS = 2 * 60 * 1000;
const COOLDOWN_KEY = "am_last_send";
let sendCooldownTimer = null;
function getCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
  const sisa = COOLDOWN_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startSendCooldown() {
  const sisaMs = getCooldownRemaining();
  if (sisaMs <= 0) {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'KIRIM LINK VERIF';
    sendBtn.classList.remove("green");
    return;
  }
  sendBtn.disabled = true;
  function tick() {
    const remaining = getCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(sendCooldownTimer);
      sendCooldownTimer = null;
      sendBtn.disabled = false;
      sendBtn.innerHTML = 'KIRIM LINK VERIF';
      sendBtn.classList.remove("green");
      return;
    }
    const totalSec = Math.ceil(remaining / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:8px;">
    </i> TUNGGU ' + m + ':' + String(s).padStart(2,
    '0');
  }
  tick();
  if (sendCooldownTimer) clearInterval(sendCooldownTimer);
  sendCooldownTimer = setInterval(tick,
  1000);
}
startSendCooldown();
sendBtn.addEventListener("click",
async () => {
  if (getCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  if (!validEmail(email)) {
    emailInput.focus();
    emailInput.style.background = "#fff0f0";
    setTimeout(() => emailInput.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_KEY,
  String(Date.now()));
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin" style="margin-right:8px;">
  </i> MENGIRIM...';
  try {
    const response = await fetch(`/api/send?email=${encodeURIComponent(email)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "Gagal mengirim permintaan.");
    }
    sendBtn.innerHTML = '✓ LINK VERIF TERKIRIM';
    sendBtn.classList.add("green");
    sendStatus.classList.add("show");
    sendBtn.disabled = true;
    card2.classList.remove("hidden");
    progress1.classList.add("done");
    progress2.classList.add("active");
    line1.style.background = "var(--primary)";
    setTimeout(() => {
      card2.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    150);
    startSendCooldown();
  }
  catch (error) {
    localStorage.removeItem(COOLDOWN_KEY);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '↻ COBA LAGI';
    sendBtn.classList.remove("green");
    sendStatus.classList.add("show");
    sendStatus.querySelector(".status-icon").innerHTML = "✗";
    sendStatus.querySelector(".status-icon").style.background = "var(--red)";
    sendStatus.querySelector("strong").textContent = "GAGAL MENGIRIM";
    sendStatus.querySelector("span").textContent = error.message || "Terjadi kesalahan server.";
  }
}
);
const COOLDOWN_VERIF_MS = 2 * 60 * 1000;
const COOLDOWN_VERIF_KEY = "am_last_verif";
let verifCooldownTimer = null;
function getVerifCooldownRemaining() {
  const last = Number(localStorage.getItem(COOLDOWN_VERIF_KEY) || 0);
  const sisa = COOLDOWN_VERIF_MS - (Date.now() - last);
  return sisa > 0 ? sisa : 0;
}
function startVerifCooldown() {
  const sisaMs = getVerifCooldownRemaining();
  if (sisaMs <= 0) {
    verifyBtn.disabled = false;
    return;
  }
  verifyBtn.disabled = true;
  function tick() {
    const remaining = getVerifCooldownRemaining();
    if (remaining <= 0) {
      clearInterval(verifCooldownTimer);
      verifCooldownTimer = null;
      verifyBtn.disabled = false;
      return;
    }
  }
  tick();
  if (verifCooldownTimer) clearInterval(verifCooldownTimer);
  verifCooldownTimer = setInterval(tick,
  1000);
}
startVerifCooldown();
verifyBtn.addEventListener("click",
async () => {
  if (getVerifCooldownRemaining() > 0) return;
  const email = emailInput.value.trim();
  const link = verifyLink.value.trim();
  if (!validEmail(email)) {
    setVerifyMessage("!",
    "EMAIL TIDAK VALID",
    "Email tidak valid. Ulangi step 1.");
    return;
  }
  if (!validVerificationLink(link)) {
    verifyLink.focus();
    verifyLink.style.background = "#fff0f0";
    setVerifyMessage("!",
    "LINK TIDAK VALID",
    "Masukkan link verifikasi Alight Motion yang benar.");
    setTimeout(() => verifyLink.style.background = "transparent",
    700);
    return;
  }
  localStorage.setItem(COOLDOWN_VERIF_KEY,
  String(Date.now()));
  verifyBtn.disabled = true;
  verifyBtn.textContent = "MEMPROSES...";
  setVerifyMessage(
  '<i class="fa-solid fa-hourglass-half" style="font-size:22px; color:#fff;">
  </i>',
  "MEMPROSES VERIFIKASI",
  "Mengirim data ke server."
  );
  try {
    const response = await fetch(`/api/verif?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`);
    if (!response.ok) {
      throw new Error('Server error: ' + response.status);
    }
    let data;
    try {
      data = await response.json();
    }
    catch (e) {
      throw new Error('Response server tidak valid.');
    }
    if (!data.success) {
      throw new Error(data.message || "API gagal memproses verifikasi.");
    }
    setVerifyMessage(
    '<i class="fa-solid fa-check" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI BERHASIL",
    data.message || "Akun berhasil diproses.",
    true
    );
    verifyBtn.textContent = "✓ BERHASIL";
    verifyBtn.classList.remove("green");
    verifyBtn.classList.add("yellow");
    verifyBtn.disabled = true;
    progress2.classList.add("done");
    progress3.classList.add("active",
    "done");
    line2.style.background = "var(--primary)";
    card3.classList.remove("hidden");
    setTimeout(() => {
      card3.scrollIntoView({
        behavior: "smooth",
        block: "center"
      }
      );
    }
    ,
    250);
  }
  catch (error) {
    setVerifyMessage(
    '<i class="fa-solid fa-xmark" style="font-size:22px; color:#fff;">
    </i>',
    "VERIFIKASI GAGAL",
    error.message || "Terjadi kesalahan saat menghubungi server."
    );
    localStorage.removeItem(COOLDOWN_VERIF_KEY);
    verifyBtn.disabled = false;
    verifyBtn.textContent = "↻ COBA LAGI";
    verifyBtn.style.opacity = "1";
  }
}
);